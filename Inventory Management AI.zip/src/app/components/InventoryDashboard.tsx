import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Sparkles } from "lucide-react";

// Import all feature components
import { CostForecast } from "./features/CostForecast";
import { RestockingBudget } from "./features/RestockingBudget";
import { ExpiryTracker } from "./features/ExpiryTracker";
import { PriceTrends } from "./features/PriceTrends";
import { StockoutRisk } from "./features/StockoutRisk";
import { BranchTransfers } from "./features/BranchTransfers";
import { SupplierScoring } from "./features/SupplierScoring";
import { HighProfitItems } from "./features/HighProfitItems";
import { UnprofitableStock } from "./features/UnprofitableStock";
import { StockoutPrediction } from "./features/StockoutPrediction";
import { ComputerVisionCount } from "./features/ComputerVisionCount";

export function InventoryDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">AI Inventory Intelligence</h1>
            <p className="text-gray-600 mt-1">Predictive analytics for smarter inventory management</p>
          </div>
          <Badge variant="outline" className="flex items-center gap-1 px-3 py-2">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium">AI-Powered</span>
          </Badge>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="finance" className="space-y-6">
          <TabsList className="grid w-full max-w-3xl grid-cols-3">
            <TabsTrigger value="finance">Finance Manager</TabsTrigger>
            <TabsTrigger value="procurement">Procurement Officer</TabsTrigger>
            <TabsTrigger value="inventory">Inventory Manager</TabsTrigger>
          </TabsList>

          {/* Finance Manager View */}
          <TabsContent value="finance" className="space-y-6">
            <CostForecast />
            <RestockingBudget />
            <ExpiryTracker />
            <HighProfitItems />
            <UnprofitableStock />
          </TabsContent>

          {/* Procurement Officer View */}
          <TabsContent value="procurement" className="space-y-6">
            <PriceTrends />
            <StockoutRisk />
            <BranchTransfers />
            <SupplierScoring />
            <StockoutPrediction />
          </TabsContent>

          {/* Inventory Manager View */}
          <TabsContent value="inventory" className="space-y-6">
            <ComputerVisionCount />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
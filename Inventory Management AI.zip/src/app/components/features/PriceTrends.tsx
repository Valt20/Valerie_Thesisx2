import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Calendar, Sparkles, TrendingDown, TrendingUp } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";

const generatePriceTrendData = (timeWindow: number, category: string) => {
  const allItems = [
    { id: 2345, name: "Laptop Stand Pro", category: "Electronics" },
    { id: 2346, name: "Wireless Mouse Elite", category: "Electronics" },
    { id: 2347, name: "USB-C Hub", category: "Electronics" },
    { id: 2348, name: "Coffee Beans Premium", category: "Beverages" },
    { id: 2349, name: "Office Chair Deluxe", category: "Furniture" },
  ];

  const filtered = category === "all" ? allItems : allItems.filter(i => i.category === category);

  return filtered.map(item => {
    const currentPrice = Math.floor(Math.random() * 50) + 30;
    const priceHistory = [];
    let price = currentPrice + (Math.random() * 20 - 10);

    // Generate price history
    for (let i = timeWindow; i >= 0; i--) {
      const variance = Math.random() * 10 - 5;
      price = Math.max(20, price + variance);
      priceHistory.push({
        day: timeWindow - i,
        price: Math.round(price * 100) / 100,
        label: i === 0 ? "Today" : `${i}d ago`
      });
    }

    // Predict future prices
    const trend = priceHistory[priceHistory.length - 1].price < priceHistory[0].price ? "down" : "up";
    const predictedBestWeek = Math.floor(Math.random() * 4) + 1;
    const predictedPrice = trend === "down" 
      ? currentPrice * (0.85 + Math.random() * 0.1)
      : currentPrice * (1.05 + Math.random() * 0.1);

    const potentialSavings = trend === "down" 
      ? Math.round((currentPrice - predictedPrice) * (Math.random() * 100 + 50))
      : 0;

    return {
      item_id: item.id,
      name: item.name,
      category: item.category,
      current_price: Math.round(currentPrice * 100) / 100,
      predicted_best_week: `Week ${predictedBestWeek}`,
      predicted_price: Math.round(predictedPrice * 100) / 100,
      price_history: priceHistory,
      advice: trend === "down" 
        ? `Buy in Week ${predictedBestWeek} when price dips`
        : `Current price is optimal, buy now`,
      trend: trend,
      confidence: Math.floor(Math.random() * 15) + 80,
      potential_savings: potentialSavings
    };
  });
};

export function PriceTrends() {
  const [timeWindow, setTimeWindow] = useState("90");
  const [category, setCategory] = useState("all");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generatePriceTrendData(parseInt(timeWindow), category);
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Optimal Reorder Timing Based on Price Trends
        </CardTitle>
        <CardDescription>
          AI-predicted best purchase windows to minimize costs based on historical price analysis
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="space-y-2">
            <Label>Price Analysis Window</Label>
            <Select value={timeWindow} onValueChange={setTimeWindow}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="60">Last 60 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="180">Last 180 days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Category Filter</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
                <SelectItem value="Beverages">Beverages</SelectItem>
                <SelectItem value="Furniture">Furniture</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-green-600 hover:bg-green-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Analyze Price Trends
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Items Analyzed</p>
                <p className="text-2xl font-bold text-blue-600">{results.length}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Downward Trends</p>
                <p className="text-2xl font-bold text-green-600">
                  {results.filter(r => r.trend === "down").length}
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Savings Potential</p>
                <p className="text-2xl font-bold text-orange-600">
                  ${results.reduce((sum, r) => sum + r.potential_savings, 0).toLocaleString()}
                </p>
              </div>
            </div>

            {/* Per-item analysis */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Price Forecast by Item</h3>
              {results.map((item, idx) => (
                <div key={idx} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.name}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        {item.trend === "down" ? (
                          <Badge className="bg-green-600">
                            <TrendingDown className="w-3 h-3 mr-1" />
                            Favorable
                          </Badge>
                        ) : (
                          <Badge variant="outline">
                            <TrendingUp className="w-3 h-3 mr-1" />
                            Stable/Rising
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mt-1">{item.advice}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600">Confidence</p>
                      <p className="text-lg font-bold">{item.confidence}%</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 bg-gray-50 rounded">
                      <p className="text-xs text-gray-600">Current Price</p>
                      <p className="text-lg font-bold">${item.current_price}</p>
                    </div>
                    <div className={`p-3 rounded ${item.trend === "down" ? "bg-green-50" : "bg-orange-50"}`}>
                      <p className="text-xs text-gray-600">Predicted Best</p>
                      <p className={`text-lg font-bold ${item.trend === "down" ? "text-green-600" : "text-orange-600"}`}>
                        ${item.predicted_price}
                      </p>
                      <p className="text-xs text-gray-600">{item.predicted_best_week}</p>
                    </div>
                    {item.potential_savings > 0 && (
                      <div className="p-3 bg-blue-50 rounded">
                        <p className="text-xs text-gray-600">Potential Savings</p>
                        <p className="text-lg font-bold text-blue-600">
                          ${item.potential_savings}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Price trend chart */}
                  <div>
                    <p className="text-xs text-gray-600 mb-2">Price History & Forecast</p>
                    <ResponsiveContainer width="100%" height={150}>
                      <LineChart data={item.price_history}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="day" 
                          tick={{ fontSize: 10 }}
                          tickFormatter={(value) => value === 0 ? "Now" : `-${value}d`}
                        />
                        <YAxis tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                        <Tooltip 
                          formatter={(value) => `$${value}`}
                          labelFormatter={(label) => label === 0 ? "Today" : `${label} days ago`}
                        />
                        <ReferenceLine 
                          y={item.predicted_price} 
                          stroke={item.trend === "down" ? "#16a34a" : "#f97316"} 
                          strokeDasharray="5 5"
                          label={{ value: "Predicted", fontSize: 10 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="price" 
                          stroke="#3b82f6" 
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-green-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-green-600" />
              <span className="text-gray-700">
                AI Insight: {results.filter(r => r.trend === "down").length} items show favorable price trends. 
                Waiting for optimal purchase windows could save ${results.reduce((sum, r) => sum + r.potential_savings, 0).toLocaleString()} 
                on your next reorder cycle.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

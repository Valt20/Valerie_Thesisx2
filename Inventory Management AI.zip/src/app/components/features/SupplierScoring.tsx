import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Slider } from "../ui/slider";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { TruckIcon, Sparkles, TrendingDown, TrendingUp, Award } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const generateSupplierData = (timeWindow: number, costWeight: number, deliveryWeight: number) => {
  const suppliers = [
    { id: "S-101", name: "TechSupply Co" },
    { id: "S-102", name: "Office Depot Plus" },
    { id: "S-103", name: "Bulk Warehouse" },
    { id: "S-104", name: "Quick Distributors" },
    { id: "S-105", name: "Global Supplies Inc" },
    { id: "S-106", name: "Premium Vendors Ltd" },
  ];

  return suppliers.map(supplier => {
    const priceChange = (Math.random() * 10 - 5); // -5% to +5%
    const onTimeRate = Math.floor(Math.random() * 15) + 85; // 85-100%
    const avgDelay = Math.random() * 4; // 0-4 days
    const leadTimeVariability = Math.random() * 3; // 0-3 days std dev
    const qualityIncidents = Math.floor(Math.random() * 5); // 0-5 incidents

    // Calculate component scores
    const costScore = 100 - Math.abs(priceChange) * 5 + (priceChange < 0 ? 10 : 0); // Bonus for price decrease
    const deliveryScore = onTimeRate - (avgDelay * 2);
    const qualityScore = 100 - (qualityIncidents * 10);
    const reliabilityScore = 100 - (leadTimeVariability * 15);

    // Weighted final score
    const finalScore = Math.round(
      (costScore * (costWeight / 100)) +
      (deliveryScore * (deliveryWeight / 100)) +
      (qualityScore * 0.15) +
      (reliabilityScore * 0.15)
    );

    return {
      supplier_id: supplier.id,
      name: supplier.name,
      score: Math.min(100, Math.max(0, finalScore)),
      average_price_change: Math.round(priceChange * 10) / 10,
      on_time_delivery: onTimeRate,
      avg_delay_days: Math.round(avgDelay * 10) / 10,
      lead_time_variability: Math.round(leadTimeVariability * 10) / 10,
      quality_incidents: qualityIncidents,
      cost_trend: priceChange < -1 ? "decreasing" : priceChange > 1 ? "increasing" : "stable",
      recommendation: "",
      total_orders: Math.floor(Math.random() * 100) + 50
    };
  }).map(supplier => {
    if (supplier.score >= 85) {
      supplier.recommendation = "Preferred Supplier - Increase orders";
    } else if (supplier.score >= 70) {
      supplier.recommendation = "Good Supplier - Maintain current volume";
    } else if (supplier.score >= 50) {
      supplier.recommendation = "Monitor - Review quarterly";
    } else {
      supplier.recommendation = "Consider alternatives - High risk";
    }
    return supplier;
  }).sort((a, b) => b.score - a.score);
};

export function SupplierScoring() {
  const [timeWindow, setTimeWindow] = useState("90");
  const [costWeight, setCostWeight] = useState([35]);
  const [deliveryWeight, setDeliveryWeight] = useState([35]);
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateSupplierData(parseInt(timeWindow), costWeight[0], deliveryWeight[0]);
    setResults(data);
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return "#10b981";
    if (score >= 70) return "#3b82f6";
    if (score >= 50) return "#f59e0b";
    return "#ef4444";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TruckIcon className="w-5 h-5" />
          Supplier Performance Scoring
        </CardTitle>
        <CardDescription>
          AI-powered supplier evaluation based on cost trends, delivery consistency, and quality
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label>Assessment Time Window</Label>
              <Select value={timeWindow} onValueChange={setTimeWindow}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                  <SelectItem value="180">Last 180 days</SelectItem>
                  <SelectItem value="365">Last 12 months</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Cost Weight</Label>
                <span className="text-sm font-bold text-blue-600">{costWeight[0]}%</span>
              </div>
              <Slider
                value={costWeight}
                onValueChange={setCostWeight}
                max={50}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-gray-600">Importance of price competitiveness</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Delivery Weight</Label>
                <span className="text-sm font-bold text-blue-600">{deliveryWeight[0]}%</span>
              </div>
              <Slider
                value={deliveryWeight}
                onValueChange={setDeliveryWeight}
                max={50}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-gray-600">Importance of on-time delivery</p>
            </div>
          </div>

          <p className="text-xs text-gray-600">
            Remaining weight (Quality: 15%, Reliability: 15%, Total: {100 - costWeight[0] - deliveryWeight[0]}% auto)
          </p>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-blue-600 hover:bg-blue-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Evaluate Suppliers
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Preferred</p>
                <p className="text-2xl font-bold text-green-600">
                  {results.filter(r => r.score >= 85).length}
                </p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Good</p>
                <p className="text-2xl font-bold text-blue-600">
                  {results.filter(r => r.score >= 70 && r.score < 85).length}
                </p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="text-sm text-gray-600">Monitor</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {results.filter(r => r.score >= 50 && r.score < 70).length}
                </p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">High Risk</p>
                <p className="text-2xl font-bold text-red-600">
                  {results.filter(r => r.score < 50).length}
                </p>
              </div>
            </div>

            {/* Score Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Supplier Score Comparison</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={results}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-15} textAnchor="end" height={80} tick={{ fontSize: 10 }} />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="score" name="Overall Score">
                    {results.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getScoreColor(entry.score)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Detailed scorecards */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Supplier Scorecards</h3>
              {results.map((supplier, idx) => (
                <div key={idx} className="border rounded-lg p-4 bg-white">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{supplier.name}</p>
                        <Badge variant="outline" className="text-xs">{supplier.supplier_id}</Badge>
                        {supplier.score >= 85 && (
                          <Badge className="bg-green-600">
                            <Award className="w-3 h-3 mr-1" />
                            Preferred
                          </Badge>
                        )}
                        {supplier.cost_trend === "decreasing" ? (
                          <Badge className="bg-green-600">
                            <TrendingDown className="w-3 h-3 mr-1" />
                            Price ↓
                          </Badge>
                        ) : supplier.cost_trend === "increasing" ? (
                          <Badge variant="destructive">
                            <TrendingUp className="w-3 h-3 mr-1" />
                            Price ↑
                          </Badge>
                        ) : (
                          <Badge variant="outline">Stable</Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mt-1">{supplier.recommendation}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-3xl font-bold`} style={{ color: getScoreColor(supplier.score) }}>
                        {supplier.score}
                      </p>
                      <p className="text-xs text-gray-600">score</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-5 gap-2 mb-3">
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-600">Price Change</p>
                      <p className={`text-sm font-bold ${
                        supplier.average_price_change < 0 ? "text-green-600" : 
                        supplier.average_price_change > 0 ? "text-red-600" : 
                        "text-gray-600"
                      }`}>
                        {supplier.average_price_change > 0 ? "+" : ""}{supplier.average_price_change}%
                      </p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-600">On-Time</p>
                      <p className="text-sm font-bold">{supplier.on_time_delivery}%</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-600">Avg Delay</p>
                      <p className="text-sm font-bold">{supplier.avg_delay_days}d</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-600">Variability</p>
                      <p className="text-sm font-bold">±{supplier.lead_time_variability}d</p>
                    </div>
                    <div className="p-2 bg-gray-50 rounded text-center">
                      <p className="text-xs text-gray-600">Incidents</p>
                      <p className={`text-sm font-bold ${supplier.quality_incidents > 2 ? "text-red-600" : "text-green-600"}`}>
                        {supplier.quality_incidents}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-gray-600">
                    <span>Total orders in period: {supplier.total_orders}</span>
                    <span>Evaluated over {timeWindow} days</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-blue-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span className="text-gray-700">
                AI Recommendation: Focus procurement on top {Math.min(3, results.filter(r => r.score >= 70).length)} suppliers 
                ({results.filter(r => r.score >= 70).map(r => r.name).slice(0, 3).join(", ")}) for optimal cost-performance balance.
                {results.filter(r => r.score < 50).length > 0 && 
                  ` Consider phasing out ${results.filter(r => r.score < 50).length} underperforming supplier(s).`
                }
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

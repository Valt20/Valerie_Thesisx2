import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Package, Sparkles, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const generateRestockData = (horizon: number, serviceLevel: number, maxSpend: number) => {
  const items = [
    { id: 5678, name: "Premium Coffee", category: "Beverages", unitCost: 3 },
    { id: 6789, name: "Wireless Mouse", category: "Electronics", unitCost: 25 },
    { id: 7890, name: "Desk Organizer", category: "Office Supplies", unitCost: 15 },
    { id: 8901, name: "Conference Chair", category: "Furniture", unitCost: 120 },
  ];

  let totalBudget = 0;
  const weeklyData = [];

  for (let week = 1; week <= horizon; week++) {
    weeklyData.push({
      week: `Week ${week}`,
      budget: Math.floor(Math.random() * (maxSpend / horizon) * 1.2)
    });
  }

  return {
    items: items.map(item => {
      const baseQty = Math.floor(Math.random() * 200) + 100;
      const adjustedQty = Math.floor(baseQty * (serviceLevel / 100));
      const weeklyBudget = adjustedQty * item.unitCost;
      totalBudget += weeklyBudget;

      const profitMargin = Math.floor(Math.random() * 30) + 15;
      const expectedProfit = (adjustedQty * item.unitCost * profitMargin) / 100;

      return {
        item_id: item.id,
        name: item.name,
        category: item.category,
        suggested_reorder_qty_week1: adjustedQty,
        suggested_budget_week1: weeklyBudget,
        rationale: `Expected demand + ${serviceLevel}% service level`,
        unit_cost: item.unitCost,
        expected_profit: Math.round(expectedProfit),
        break_even: expectedProfit > weeklyBudget * 0.15
      };
    }),
    weeklyData,
    totalBudget: Math.min(totalBudget, maxSpend),
    withinBudget: totalBudget <= maxSpend
  };
};

export function RestockingBudget() {
  const [horizon, setHorizon] = useState("4");
  const [serviceLevel, setServiceLevel] = useState("95");
  const [maxSpend, setMaxSpend] = useState("50000");
  const [results, setResults] = useState<any | null>(null);

  const handleGenerate = () => {
    const data = generateRestockData(parseInt(horizon), parseInt(serviceLevel), parseInt(maxSpend));
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Restocking Budget Prediction
        </CardTitle>
        <CardDescription>
          Calculate optimal reorder quantities and budget needed to meet service level targets
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
          <div className="space-y-2">
            <Label>Forecast Horizon</Label>
            <Select value={horizon} onValueChange={setHorizon}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4">4 weeks</SelectItem>
                <SelectItem value="8">8 weeks</SelectItem>
                <SelectItem value="12">12 weeks</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Target Service Level (%)</Label>
            <Select value={serviceLevel} onValueChange={setServiceLevel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">90% - Standard</SelectItem>
                <SelectItem value="95">95% - High</SelectItem>
                <SelectItem value="99">99% - Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Max Monthly Spend ($)</Label>
            <Input
              type="number"
              value={maxSpend}
              onChange={(e) => setMaxSpend(e.target.value)}
              placeholder="50000"
            />
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-purple-600 hover:bg-purple-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Calculate Restocking Budget
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-3 gap-4">
              <div className={`p-4 rounded-lg ${results.withinBudget ? 'bg-green-50' : 'bg-red-50'}`}>
                <p className="text-sm text-gray-600">Total Restock Budget</p>
                <p className={`text-2xl font-bold ${results.withinBudget ? 'text-green-600' : 'text-red-600'}`}>
                  ${results.totalBudget.toLocaleString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">
                  {results.withinBudget ? "Within budget" : "Exceeds limit"}
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Service Level</p>
                <p className="text-2xl font-bold text-blue-600">{serviceLevel}%</p>
                <p className="text-xs text-gray-600 mt-1">Target achievement</p>
              </div>

              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">Items to Reorder</p>
                <p className="text-2xl font-bold text-orange-600">{results.items.length}</p>
                <p className="text-xs text-gray-600 mt-1">Next {horizon} weeks</p>
              </div>
            </div>

            {/* Weekly Budget Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Weekly Spend Forecast</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={results.weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Bar dataKey="budget" fill="#9333ea" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Per-item recommendations */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Recommended Reorder Quantities</h3>
              {results.items.map((item: any, idx: number) => (
                <div key={idx} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.name}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        {item.break_even && (
                          <Badge className="bg-green-600 text-xs">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Break-even justified
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mt-1">{item.rationale}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4">
                    <div className="p-3 bg-gray-50 rounded">
                      <p className="text-xs text-gray-600">Suggested Qty</p>
                      <p className="text-lg font-bold">{item.suggested_reorder_qty_week1}</p>
                      <p className="text-xs text-gray-600">units</p>
                    </div>
                    <div className="p-3 bg-gray-50 rounded">
                      <p className="text-xs text-gray-600">Unit Cost</p>
                      <p className="text-lg font-bold">${item.unit_cost}</p>
                      <p className="text-xs text-gray-600">per unit</p>
                    </div>
                    <div className="p-3 bg-purple-50 rounded">
                      <p className="text-xs text-gray-600">Week 1 Budget</p>
                      <p className="text-lg font-bold text-purple-600">
                        ${item.suggested_budget_week1.toLocaleString()}
                      </p>
                    </div>
                    <div className="p-3 bg-green-50 rounded">
                      <p className="text-xs text-gray-600">Expected Profit</p>
                      <p className="text-lg font-bold text-green-600">
                        ${item.expected_profit.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-purple-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-gray-700">
                AI Recommendation: {results.withinBudget 
                  ? `Budget is well-allocated. Consider investing remaining ${(parseInt(maxSpend) - results.totalBudget).toLocaleString()} in high-margin items.`
                  : `Budget exceeded by $${(results.totalBudget - parseInt(maxSpend)).toLocaleString()}. Consider reducing service level to 90% or increasing budget cap.`
                }
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

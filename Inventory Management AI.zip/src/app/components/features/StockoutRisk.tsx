import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Target, Sparkles, AlertTriangle, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const generateStockoutData = (serviceLevel: number, leadTime: number) => {
  const items = [
    { id: 3456, name: "Paper A4 Ream", category: "Office Supplies" },
    { id: 3457, name: "Desk Lamp LED", category: "Electronics" },
    { id: 3458, name: "Office Chair Pro", category: "Furniture" },
    { id: 3459, name: "Stapler Heavy Duty", category: "Office Supplies" },
    { id: 3460, name: "Whiteboard Marker", category: "Office Supplies" },
  ];

  return items.map(item => {
    const avgDemand = Math.floor(Math.random() * 100) + 50;
    const demandVariability = Math.random() * 0.3 + 0.1; // 10-40% variability
    const leadTimeVariability = Math.random() * 3 + 1; // 1-4 days

    // Calculate safety stock based on service level
    // Z-score approximation: 90% ≈ 1.28, 95% ≈ 1.65, 99% ≈ 2.33
    const zScore = serviceLevel === 90 ? 1.28 : serviceLevel === 95 ? 1.65 : 2.33;
    const safetyStock = Math.ceil(zScore * Math.sqrt(leadTime) * avgDemand * demandVariability);
    const minRequired = (avgDemand * leadTime / 30) + safetyStock; // Monthly to daily conversion
    const currentStock = Math.floor(Math.random() * minRequired * 1.5);

    let stockoutRisk = "low";
    if (currentStock < safetyStock) stockoutRisk = "critical";
    else if (currentStock < minRequired * 0.8) stockoutRisk = "high";
    else if (currentStock < minRequired) stockoutRisk = "medium";

    const daysUntilStockout = Math.max(0, Math.floor(currentStock / (avgDemand / 30)));

    return {
      item_id: item.id,
      name: item.name,
      category: item.category,
      current_stock: currentStock,
      safety_stock: safetyStock,
      min_required: Math.ceil(minRequired),
      stockout_risk: stockoutRisk,
      avg_daily_demand: Math.round((avgDemand / 30) * 10) / 10,
      lead_time_days: leadTime,
      days_until_stockout: daysUntilStockout,
      recommended_order_qty: Math.max(0, Math.ceil(minRequired - currentStock) + avgDemand)
    };
  });
};

export function StockoutRisk() {
  const [serviceLevel, setServiceLevel] = useState("95");
  const [leadTime, setLeadTime] = useState("14");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateStockoutData(parseInt(serviceLevel), parseInt(leadTime));
    setResults(data.sort((a, b) => {
      const riskOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return riskOrder[a.stockout_risk as keyof typeof riskOrder] - riskOrder[b.stockout_risk as keyof typeof riskOrder];
    }));
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "critical": return "#ef4444";
      case "high": return "#f97316";
      case "medium": return "#f59e0b";
      default: return "#10b981";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5" />
          Minimum Stock vs Stockout Risk
        </CardTitle>
        <CardDescription>
          Calculate optimal safety stock levels to prevent stockouts while minimizing holding costs
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
          <div className="space-y-2">
            <Label>Desired Service Level (%)</Label>
            <Select value={serviceLevel} onValueChange={setServiceLevel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">90% - Standard</SelectItem>
                <SelectItem value="95">95% - High</SelectItem>
                <SelectItem value="99">99% - Critical</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-600">Higher service levels require more safety stock</p>
          </div>

          <div className="space-y-2">
            <Label>Average Lead Time (days)</Label>
            <Input
              type="number"
              value={leadTime}
              onChange={(e) => setLeadTime(e.target.value)}
              placeholder="14"
              min="1"
              max="60"
            />
            <p className="text-xs text-gray-600">Supplier delivery time + processing</p>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-orange-600 hover:bg-orange-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Calculate Safety Stock Levels
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">Critical Risk</p>
                <p className="text-2xl font-bold text-red-600">
                  {results.filter(r => r.stockout_risk === "critical").length}
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">High Risk</p>
                <p className="text-2xl font-bold text-orange-600">
                  {results.filter(r => r.stockout_risk === "high").length}
                </p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="text-sm text-gray-600">Medium Risk</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {results.filter(r => r.stockout_risk === "medium").length}
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Low Risk</p>
                <p className="text-2xl font-bold text-green-600">
                  {results.filter(r => r.stockout_risk === "low").length}
                </p>
              </div>
            </div>

            {/* Stock Health Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Stock Health Overview</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={results}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-15} textAnchor="end" height={80} tick={{ fontSize: 10 }} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="current_stock" name="Current Stock">
                    {results.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getRiskColor(entry.stockout_risk)} />
                    ))}
                  </Bar>
                  <Bar dataKey="min_required" name="Min Required" fill="#94a3b8" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Per-item details */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Stock Health by Item</h3>
              {results.map((item, idx) => (
                <div 
                  key={idx}
                  className={`border rounded-lg p-4 ${
                    item.stockout_risk === "critical" ? "bg-red-50 border-red-300" :
                    item.stockout_risk === "high" ? "bg-orange-50 border-orange-300" :
                    item.stockout_risk === "medium" ? "bg-yellow-50 border-yellow-300" :
                    "bg-green-50 border-green-300"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.name}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge 
                          variant={item.stockout_risk === "critical" || item.stockout_risk === "high" ? "destructive" : "default"}
                          className={
                            item.stockout_risk === "high" ? "bg-orange-600" :
                            item.stockout_risk === "medium" ? "bg-yellow-600" :
                            item.stockout_risk === "low" ? "bg-green-600" : ""
                          }
                        >
                          {item.stockout_risk} risk
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">{item.category}</p>
                    </div>
                    {item.stockout_risk === "low" ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <AlertTriangle className={`w-6 h-6 ${
                        item.stockout_risk === "critical" ? "text-red-600" :
                        item.stockout_risk === "high" ? "text-orange-600" :
                        "text-yellow-600"
                      }`} />
                    )}
                  </div>

                  <div className="grid grid-cols-4 gap-3 mb-3">
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Current Stock</p>
                      <p className="text-lg font-bold">{item.current_stock}</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Safety Stock</p>
                      <p className="text-lg font-bold text-blue-600">{item.safety_stock}</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Min Required</p>
                      <p className="text-lg font-bold text-orange-600">{item.min_required}</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Days Until Out</p>
                      <p className={`text-lg font-bold ${
                        item.days_until_stockout < 7 ? "text-red-600" :
                        item.days_until_stockout < 14 ? "text-orange-600" :
                        "text-green-600"
                      }`}>
                        {item.days_until_stockout}
                      </p>
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
                      <span>Stock Level</span>
                      <span>{Math.round((item.current_stock / item.min_required) * 100)}% of minimum</span>
                    </div>
                    <div className="h-3 bg-white rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${
                          item.stockout_risk === "critical" ? "bg-red-600" :
                          item.stockout_risk === "high" ? "bg-orange-600" :
                          item.stockout_risk === "medium" ? "bg-yellow-600" :
                          "bg-green-600"
                        }`}
                        style={{ width: `${Math.min((item.current_stock / item.min_required) * 100, 100)}%` }}
                      />
                    </div>
                  </div>

                  {item.recommended_order_qty > 0 && (
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div>
                        <p className="text-xs text-gray-600">Recommended Order</p>
                        <p className="text-sm font-medium">
                          {item.recommended_order_qty} units to reach optimal level
                        </p>
                      </div>
                      <Button size="sm" variant={item.stockout_risk === "critical" ? "destructive" : "default"}>
                        Order Now
                      </Button>
                    </div>
                  )}

                  <div className="mt-2 text-xs text-gray-600">
                    Avg daily demand: {item.avg_daily_demand} units • Lead time: {item.lead_time_days} days
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-orange-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-orange-600" />
              <span className="text-gray-700">
                AI Insight: With {serviceLevel}% service level and {leadTime}-day lead time, 
                {results.filter(r => r.stockout_risk === "critical" || r.stockout_risk === "high").length > 0 
                  ? ` ${results.filter(r => r.stockout_risk === "critical" || r.stockout_risk === "high").length} items need immediate attention to prevent stockouts.`
                  : " all items are adequately stocked to maintain service levels."
                }
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

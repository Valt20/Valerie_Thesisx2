import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { TrendingDown, Sparkles, XCircle, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const generateUnprofitableData = (horizon: number) => {
  const items = [
    { id: 567, name: "Old Model Printer XYZ", category: "Electronics" },
    { id: 568, name: "Discontinued Mouse Pad", category: "Office Supplies" },
    { id: 569, name: "Legacy Monitor 19-inch", category: "Electronics" },
    { id: 570, name: "Basic Calculator V1", category: "Office Supplies" },
    { id: 571, name: "Outdated Desk Lamp", category: "Furniture" },
    { id: 572, name: "Old Scanner Model", category: "Electronics" },
  ];

  return items.map(item => {
    const quantity = Math.floor(Math.random() * 100) + 20;
    const storageCostPerUnit = (Math.random() * 5) + 1;
    const sellingPrice = storageCostPerUnit * (0.3 + Math.random() * 0.7); // 30-100% of storage cost
    const unitProfit = sellingPrice - storageCostPerUnit;
    
    const monthlySales = Math.floor(Math.random() * 5) + 1; // Low sales
    const monthlyStorageCost = quantity * storageCostPerUnit;
    const monthlySaleRevenue = monthlySales * sellingPrice;
    const monthlyLoss = monthlyStorageCost - monthlySaleRevenue;
    
    const totalLoss = (monthlyLoss * (horizon / 4)); // Convert weeks to months
    
    let recommendation = "";
    let urgency = "";
    
    if (unitProfit < 0) {
      recommendation = "Discontinue immediately - selling at loss";
      urgency = "critical";
    } else if (monthlyLoss > 100) {
      recommendation = "Liquidate - bundle or discount heavily";
      urgency = "high";
    } else if (monthlyLoss > 50) {
      recommendation = "Reduce stock - negotiate storage or renegotiate pricing";
      urgency = "medium";
    } else {
      recommendation = "Monitor closely - consider bundling with popular items";
      urgency = "low";
    }
    
    return {
      item_id: item.id,
      product: item.name,
      category: item.category,
      storage_cost_per_unit: Math.round(storageCostPerUnit * 100) / 100,
      sale_revenue_per_unit: Math.round(sellingPrice * 100) / 100,
      unit_profit: Math.round(unitProfit * 100) / 100,
      quantity: quantity,
      monthly_storage_cost: Math.round(monthlyStorageCost),
      monthly_revenue: Math.round(monthlySaleRevenue),
      monthly_loss: Math.round(monthlyLoss),
      total_loss_forecast: Math.round(totalLoss),
      decision: recommendation,
      urgency: urgency,
      monthly_sales: monthlySales,
      turnover_ratio: Math.round((monthlySales / quantity) * 100 * 10) / 10
    };
  }).sort((a, b) => b.monthly_loss - a.monthly_loss);
};

export function UnprofitableStock() {
  const [horizon, setHorizon] = useState("12");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateUnprofitableData(parseInt(horizon));
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-red-600" />
          High Storage Cost vs Low Revenue Items
        </CardTitle>
        <CardDescription>
          Identify products where storage costs exceed profitability - candidates for discontinuation
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 gap-4 p-4 bg-red-50 rounded-lg border border-red-200">
          <div className="space-y-2">
            <Label>Analysis Horizon</Label>
            <Select value={horizon} onValueChange={setHorizon}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4">4 weeks (1 month)</SelectItem>
                <SelectItem value="12">12 weeks (quarter)</SelectItem>
                <SelectItem value="26">26 weeks (half year)</SelectItem>
                <SelectItem value="52">52 weeks (year)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-red-600 hover:bg-red-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Identify Unprofitable Items
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Monthly Loss</p>
                <p className="text-2xl font-bold text-red-600">
                  ${results.reduce((sum, r) => sum + r.monthly_loss, 0).toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">Forecast Loss</p>
                <p className="text-2xl font-bold text-orange-600">
                  ${results.reduce((sum, r) => sum + r.total_loss_forecast, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">{horizon} weeks</p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="text-sm text-gray-600">Critical Items</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {results.filter(r => r.urgency === "critical").length}
                </p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Items Analyzed</p>
                <p className="text-2xl font-bold text-gray-600">{results.length}</p>
              </div>
            </div>

            {/* Loss Comparison Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Monthly Loss by Item</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={results}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="product" angle={-15} textAnchor="end" height={100} tick={{ fontSize: 10 }} />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value}`} />
                  <Bar dataKey="monthly_loss" name="Monthly Loss">
                    {results.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={
                        entry.urgency === "critical" ? "#ef4444" :
                        entry.urgency === "high" ? "#f97316" :
                        entry.urgency === "medium" ? "#f59e0b" :
                        "#94a3b8"
                      } />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Detailed items */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">Storage Burden Items</h3>
              {results.map((item, idx) => (
                <div 
                  key={idx}
                  className={`border rounded-lg p-4 ${
                    item.urgency === "critical" ? "bg-red-50 border-red-300" :
                    item.urgency === "high" ? "bg-orange-50 border-orange-300" :
                    item.urgency === "medium" ? "bg-yellow-50 border-yellow-300" :
                    "bg-gray-50 border-gray-300"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.product}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        <Badge 
                          variant={item.urgency === "critical" || item.urgency === "high" ? "destructive" : "default"}
                          className={
                            item.urgency === "high" ? "bg-orange-600" :
                            item.urgency === "medium" ? "bg-yellow-600" : ""
                          }
                        >
                          {item.urgency}
                        </Badge>
                      </div>
                    </div>
                    {item.urgency === "critical" ? (
                      <XCircle className="w-6 h-6 text-red-600" />
                    ) : (
                      <AlertCircle className={`w-6 h-6 ${
                        item.urgency === "high" ? "text-orange-600" :
                        item.urgency === "medium" ? "text-yellow-600" :
                        "text-gray-600"
                      }`} />
                    )}
                  </div>

                  <div className="grid grid-cols-5 gap-2 mb-3">
                    <div className="p-2 bg-white rounded text-center">
                      <p className="text-xs text-gray-600">Storage Cost</p>
                      <p className="text-sm font-bold">${item.storage_cost_per_unit}</p>
                      <p className="text-xs text-gray-600">per unit</p>
                    </div>
                    <div className="p-2 bg-white rounded text-center">
                      <p className="text-xs text-gray-600">Sale Price</p>
                      <p className="text-sm font-bold">${item.sale_revenue_per_unit}</p>
                      <p className="text-xs text-gray-600">per unit</p>
                    </div>
                    <div className="p-2 bg-white rounded text-center">
                      <p className="text-xs text-gray-600">Unit Profit</p>
                      <p className={`text-sm font-bold ${item.unit_profit < 0 ? "text-red-600" : "text-green-600"}`}>
                        ${item.unit_profit}
                      </p>
                    </div>
                    <div className="p-2 bg-white rounded text-center">
                      <p className="text-xs text-gray-600">Quantity</p>
                      <p className="text-sm font-bold">{item.quantity}</p>
                      <p className="text-xs text-gray-600">units</p>
                    </div>
                    <div className="p-2 bg-white rounded text-center">
                      <p className="text-xs text-gray-600">Turnover</p>
                      <p className="text-sm font-bold">{item.turnover_ratio}%</p>
                      <p className="text-xs text-gray-600">/month</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 mb-3">
                    <div className="p-3 bg-white rounded">
                      <p className="text-xs text-gray-600">Monthly Storage</p>
                      <p className="text-lg font-bold">${item.monthly_storage_cost}</p>
                    </div>
                    <div className="p-3 bg-white rounded">
                      <p className="text-xs text-gray-600">Monthly Revenue</p>
                      <p className="text-lg font-bold">${item.monthly_revenue}</p>
                      <p className="text-xs text-gray-600">{item.monthly_sales} sales</p>
                    </div>
                    <div className="p-3 bg-red-50 rounded border border-red-200">
                      <p className="text-xs text-gray-600">Monthly Loss</p>
                      <p className="text-lg font-bold text-red-600">${item.monthly_loss}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex-1">
                      <p className="text-xs text-gray-600">Recommendation</p>
                      <p className="text-sm font-medium">{item.decision}</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Forecast loss over {horizon} weeks: <span className="font-bold text-red-600">${item.total_loss_forecast}</span>
                      </p>
                    </div>
                    <Button size="sm" variant="destructive">
                      {item.urgency === "critical" ? "Discontinue" : "Take Action"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-red-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-red-600" />
              <span className="text-gray-700">
                AI Recommendation: Liquidating or discontinuing these items could save 
                ${results.reduce((sum, r) => sum + r.monthly_loss, 0).toLocaleString()}/month 
                (${results.reduce((sum, r) => sum + r.total_loss_forecast, 0).toLocaleString()} over {horizon} weeks) 
                in storage costs. Focus on {results.filter(r => r.urgency === "critical" || r.urgency === "high").length} 
                high-urgency items first.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

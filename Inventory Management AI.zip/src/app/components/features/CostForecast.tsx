import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { TrendingUp, TrendingDown, Sparkles } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// Mock data generation
const generateForecastData = (horizon: number, category: string, costType: string) => {
  const items = [
    { id: 1234, name: "Green Tea XYZ", category: "Beverages" },
    { id: 2345, name: "Coffee Beans Premium", category: "Beverages" },
    { id: 3456, name: "Desk Lamp LED", category: "Electronics" },
    { id: 4567, name: "Office Chair Pro", category: "Furniture" },
    { id: 5678, name: "Paper A4 Box", category: "Office Supplies" },
  ];

  const filtered = category === "all" ? items : items.filter(i => i.category === category);

  return filtered.map(item => {
    const weekData = [];
    let baseCost = Math.floor(Math.random() * 1500) + 500;
    
    for (let i = 1; i <= horizon; i++) {
      const variance = Math.random() * 200 - 100;
      baseCost = Math.max(300, baseCost + variance);
      weekData.push({
        week: i,
        cost: Math.round(baseCost)
      });
    }

    const totalCost = weekData.reduce((sum, w) => sum + w.cost, 0);
    const trend = weekData[weekData.length - 1].cost > weekData[0].cost ? "up" : "down";
    const risk = totalCost > horizon * 1000 ? "high" : totalCost > horizon * 600 ? "medium" : "low";

    return {
      item_id: item.id,
      name: item.name,
      category: item.category,
      weeklyData: weekData,
      total_forecast_cost: totalCost,
      risk_flag: risk,
      trend: trend,
      confidence: Math.floor(Math.random() * 15) + 85
    };
  });
};

export function CostForecast() {
  const [horizon, setHorizon] = useState("8");
  const [category, setCategory] = useState("all");
  const [costType, setCostType] = useState("storage");
  const [currency, setCurrency] = useState("USD");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateForecastData(parseInt(horizon), category, costType);
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Inventory Cost Forecast
        </CardTitle>
        <CardDescription>
          Forecast holding, purchase, or ordering costs for upcoming weeks
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="space-y-2">
            <Label>Forecast Horizon</Label>
            <Select value={horizon} onValueChange={setHorizon}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4">4 weeks</SelectItem>
                <SelectItem value="8">8 weeks</SelectItem>
                <SelectItem value="12">12 weeks</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Category Filter</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Beverages">Beverages</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
                <SelectItem value="Furniture">Furniture</SelectItem>
                <SelectItem value="Office Supplies">Office Supplies</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Cost Type</Label>
            <Select value={costType} onValueChange={setCostType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="storage">Storage Cost</SelectItem>
                <SelectItem value="purchase">Purchase Cost</SelectItem>
                <SelectItem value="ordering">Ordering Cost</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Currency</Label>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD ($)</SelectItem>
                <SelectItem value="EUR">EUR (€)</SelectItem>
                <SelectItem value="GBP">GBP (£)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate AI Forecast
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Forecast Results</h3>
              <Badge variant="outline">
                {currency} • {costType} • {horizon} weeks
              </Badge>
            </div>

            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Forecast</p>
                <p className="text-2xl font-bold">
                  ${results.reduce((sum, r) => sum + r.total_forecast_cost, 0).toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">High Risk Items</p>
                <p className="text-2xl font-bold text-red-600">
                  {results.filter(r => r.risk_flag === "high").length}
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Avg Confidence</p>
                <p className="text-2xl font-bold text-green-600">
                  {Math.round(results.reduce((sum, r) => sum + r.confidence, 0) / results.length)}%
                </p>
              </div>
            </div>

            {/* Per-item results */}
            <div className="space-y-4">
              {results.map((item, idx) => (
                <div key={idx} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.name}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm">
                        <span className="text-gray-600">
                          Total: <span className="font-bold">${item.total_forecast_cost.toLocaleString()}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          {item.trend === "up" ? (
                            <TrendingUp className="w-4 h-4 text-red-600" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-green-600" />
                          )}
                          <span className="text-gray-600">Trending {item.trend}</span>
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-xs text-gray-600">Confidence</p>
                        <p className="text-lg font-bold">{item.confidence}%</p>
                      </div>
                      <Badge 
                        variant={
                          item.risk_flag === "high" ? "destructive" :
                          item.risk_flag === "medium" ? "default" : "outline"
                        }
                      >
                        {item.risk_flag} risk
                      </Badge>
                    </div>
                  </div>

                  <ResponsiveContainer width="100%" height={80}>
                    <LineChart data={item.weeklyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="week" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(value) => `$${value}`} />
                      <Line type="monotone" dataKey="cost" stroke="#3b82f6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>

                  <div className="grid grid-cols-8 gap-2 text-xs">
                    {item.weeklyData.map((week: any, widx: number) => (
                      <div key={widx} className="text-center p-1 bg-gray-50 rounded">
                        <p className="text-gray-600">W{week.week}</p>
                        <p className="font-bold">${week.cost}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-blue-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span className="text-gray-700">
                AI Insight: {category === "all" ? "All categories" : category} showing {
                  results.filter(r => r.trend === "up").length > results.filter(r => r.trend === "down").length
                    ? "increasing cost trends"
                    : "decreasing cost trends"
                }. Budget allocation is {
                  results.filter(r => r.risk_flag === "high").length > 2 ? "tight" : "adequate"
                }.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

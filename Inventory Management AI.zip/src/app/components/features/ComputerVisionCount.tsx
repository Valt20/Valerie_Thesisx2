import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Camera, AlertTriangle, CheckCircle2, Sparkles, Eye } from "lucide-react";

// Product inventory data
const PRODUCTS = [
  "Big Ships", "Biskrem", "Fine", "Freska", "Hohos", "Milk", "Nescafe G",
  "PLYMS Tur", "Pantene O", "RedBull", "Shampoo I", "Rioodet", "Supermi in",
  "V Cola", "Zabado", "bless cond", "cadbury da", "juhayna m", "nivea cre",
  "oreo origin", "pepsi", "pyrosol", "suntop", "tiger chilli i"
];

const generateInventoryCount = (warehouse: string, category: string) => {
  return PRODUCTS.map((product) => {
    const aiCount = Math.floor(Math.random() * 31); // 0-30 range
    const systemCount = Math.floor(Math.random() * 31);
    const discrepancy = aiCount - systemCount;
    const status = discrepancy === 0 ? "match" : Math.abs(discrepancy) <= 2 ? "minor" : "critical";

    return {
      product,
      ai_detected_count: aiCount,
      system_count: systemCount,
      discrepancy,
      status,
      confidence: Math.floor(Math.random() * 10) + 90, // 90-100%
      category: category === "all" ? ["Beverages", "Food", "Personal Care", "Household"][Math.floor(Math.random() * 4)] : category
    };
  });
};

export function ComputerVisionCount() {
  const [warehouse, setWarehouse] = useState("main");
  const [category, setCategory] = useState("all");
  const [scanArea, setScanArea] = useState("shelf-a");
  const [results, setResults] = useState<any[] | null>(null);

  const handleScan = () => {
    const data = generateInventoryCount(warehouse, category);
    setResults(data);
  };

  const stats = results ? {
    total: results.length,
    matches: results.filter(r => r.status === "match").length,
    minor: results.filter(r => r.status === "minor").length,
    critical: results.filter(r => r.status === "critical").length,
    avgConfidence: Math.round(results.reduce((sum, r) => sum + r.confidence, 0) / results.length),
    totalDiscrepancy: results.reduce((sum, r) => sum + Math.abs(r.discrepancy), 0)
  } : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Computer Vision Inventory Count
        </CardTitle>
        <CardDescription>
          AI-powered physical inventory counting to prevent manual errors and ensure accuracy
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="space-y-2">
            <Label>Warehouse/Branch</Label>
            <Select value={warehouse} onValueChange={setWarehouse}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="main">Main Warehouse</SelectItem>
                <SelectItem value="branch-a">Branch A - Downtown</SelectItem>
                <SelectItem value="branch-b">Branch B - North</SelectItem>
                <SelectItem value="branch-c">Branch C - East</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Product Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Beverages">Beverages</SelectItem>
                <SelectItem value="Food">Food</SelectItem>
                <SelectItem value="Personal Care">Personal Care</SelectItem>
                <SelectItem value="Household">Household</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Scan Area</Label>
            <Select value={scanArea} onValueChange={setScanArea}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="shelf-a">Shelf A</SelectItem>
                <SelectItem value="shelf-b">Shelf B</SelectItem>
                <SelectItem value="full-warehouse">Full Warehouse</SelectItem>
                <SelectItem value="receiving">Receiving Dock</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleScan} className="w-full">
          <Eye className="w-4 h-4 mr-2" />
          Start AI Visual Count
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Computer Vision Results</h3>
              <Badge variant="outline">
                {warehouse} • {category} • {scanArea}
              </Badge>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <p className="text-sm text-gray-600">Perfect Matches</p>
                </div>
                <p className="text-2xl font-bold text-green-600">{stats.matches}</p>
              </div>

              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <p className="text-sm text-gray-600">Minor Variance</p>
                </div>
                <p className="text-2xl font-bold text-yellow-600">{stats.minor}</p>
              </div>

              <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  <p className="text-sm text-gray-600">Critical Issues</p>
                </div>
                <p className="text-2xl font-bold text-red-600">{stats.critical}</p>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-1">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <p className="text-sm text-gray-600">Avg Confidence</p>
                </div>
                <p className="text-2xl font-bold text-blue-600">{stats.avgConfidence}%</p>
              </div>
            </div>

            {/* Detailed Table */}
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-100 px-4 py-3 border-b">
                <h4 className="font-semibold">Product Count Analysis</h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Product</th>
                      <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Category</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">AI Count</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">System Count</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">Variance</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">Confidence</th>
                      <th className="px-4 py-3 text-center text-sm font-medium text-gray-700">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.map((item, idx) => (
                      <tr key={idx} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 font-medium">{item.product}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className="text-xs">{item.category}</Badge>
                        </td>
                        <td className="px-4 py-3 text-center font-bold text-blue-600">
                          {item.ai_detected_count}
                        </td>
                        <td className="px-4 py-3 text-center text-gray-600">
                          {item.system_count}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className={`font-bold ${
                            item.discrepancy === 0 ? 'text-green-600' :
                            item.discrepancy > 0 ? 'text-blue-600' : 'text-red-600'
                          }`}>
                            {item.discrepancy > 0 ? '+' : ''}{item.discrepancy}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center text-sm text-gray-600">
                          {item.confidence}%
                        </td>
                        <td className="px-4 py-3 text-center">
                          <Badge variant={
                            item.status === "match" ? "outline" :
                            item.status === "minor" ? "default" : "destructive"
                          } className="text-xs">
                            {item.status === "match" ? "✓ Match" :
                             item.status === "minor" ? "△ Minor" : "! Critical"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Action Items */}
            {stats.critical > 0 && (
              <div className="border-l-4 border-red-500 bg-red-50 p-4 rounded">
                <h4 className="font-semibold text-red-900 mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Critical Discrepancies Detected
                </h4>
                <ul className="space-y-1 text-sm text-red-800">
                  {results.filter(r => r.status === "critical").slice(0, 5).map((item, idx) => (
                    <li key={idx}>
                      • <strong>{item.product}</strong>: AI detected {item.ai_detected_count} units but system shows {item.system_count}
                      (variance: {item.discrepancy > 0 ? '+' : ''}{item.discrepancy} units)
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* AI Insights */}
            <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <Sparkles className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div className="space-y-2 text-sm text-gray-700">
                <p className="font-semibold text-blue-900">AI Recommendations:</p>
                <ul className="space-y-1">
                  {stats.critical > 0 && (
                    <li>• <strong>Immediate action required:</strong> {stats.critical} product{stats.critical > 1 ? 's have' : ' has'} critical count discrepancies. Initiate manual recount for verification.</li>
                  )}
                  {stats.minor > 0 && (
                    <li>• {stats.minor} product{stats.minor > 1 ? 's show' : ' shows'} minor variance. Schedule routine recount during next cycle.</li>
                  )}
                  {stats.totalDiscrepancy > 20 && (
                    <li>• High total variance detected ({stats.totalDiscrepancy} units). Review inventory handling procedures and staff training.</li>
                  )}
                  {stats.matches > stats.total * 0.7 && (
                    <li>• <strong>Good accuracy:</strong> {Math.round((stats.matches / stats.total) * 100)}% of items match perfectly. Current inventory practices are effective.</li>
                  )}
                  <li>• Next scan recommended: {warehouse === "main" ? "24 hours" : "48 hours"} from now to track accuracy trends.</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

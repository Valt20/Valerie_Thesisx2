import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { AlertTriangle, Sparkles, Tag, ArrowRightLeft } from "lucide-react";

const generateExpiryData = (expiryWindow: number, branch: string, category: string) => {
  const allItems = [
    { id: 9012, name: "Fresh Milk", category: "Beverages", branch: "Branch A", costPerUnit: 2 },
    { id: 9013, name: "Organic Yogurt", category: "Beverages", branch: "Branch B", costPerUnit: 3 },
    { id: 9014, name: "Coffee Beans Premium", category: "Beverages", branch: "Branch A", costPerUnit: 15 },
    { id: 9015, name: "LED Bulbs", category: "Electronics", branch: "Branch C", costPerUnit: 8 },
    { id: 9016, name: "Desk Plant Soil", category: "Office Supplies", branch: "Branch B", costPerUnit: 5 },
    { id: 9017, name: "Bakery Snacks", category: "Beverages", branch: "Branch A", costPerUnit: 4 },
  ];

  let filtered = allItems;
  if (branch !== "all") filtered = filtered.filter(i => i.branch === branch);
  if (category !== "all") filtered = filtered.filter(i => i.category === category);

  return filtered.map(item => {
    const daysToExpiry = Math.floor(Math.random() * expiryWindow);
    const currentStock = Math.floor(Math.random() * 200) + 50;
    const potentialLoss = currentStock * item.costPerUnit;
    
    let recommendedAction = "";
    let estimatedSavings = 0;

    if (daysToExpiry <= 5) {
      recommendedAction = "Bundle + discount 40%";
      estimatedSavings = Math.round(potentialLoss * 0.6);
    } else if (daysToExpiry <= 10) {
      recommendedAction = "Discount 25%";
      estimatedSavings = Math.round(potentialLoss * 0.75);
    } else if (daysToExpiry <= 20) {
      recommendedAction = "Promote + transfer to high-traffic branch";
      estimatedSavings = Math.round(potentialLoss * 0.85);
    } else {
      recommendedAction = "Halt new orders";
      estimatedSavings = Math.round(potentialLoss * 0.95);
    }

    return {
      item_id: item.id,
      name: item.name,
      category: item.category,
      branch: item.branch,
      days_to_expiry: daysToExpiry,
      current_stock: currentStock,
      potential_loss: potentialLoss,
      recommended_action: recommendedAction,
      estimated_savings: estimatedSavings,
      urgency: daysToExpiry <= 5 ? "critical" : daysToExpiry <= 10 ? "high" : "medium"
    };
  }).filter(item => item.days_to_expiry <= expiryWindow);
};

export function ExpiryTracker() {
  const [expiryWindow, setExpiryWindow] = useState("30");
  const [branch, setBranch] = useState("all");
  const [category, setCategory] = useState("all");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateExpiryData(parseInt(expiryWindow), branch, category);
    setResults(data.sort((a, b) => a.days_to_expiry - b.days_to_expiry));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          Items Close to Expiry
        </CardTitle>
        <CardDescription>
          Identify products approaching expiration to reduce financial losses
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-red-50 rounded-lg border border-red-200">
          <div className="space-y-2">
            <Label>Expiry Window</Label>
            <Select value={expiryWindow} onValueChange={setExpiryWindow}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 days</SelectItem>
                <SelectItem value="14">14 days</SelectItem>
                <SelectItem value="30">30 days</SelectItem>
                <SelectItem value="60">60 days</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Branch Filter</Label>
            <Select value={branch} onValueChange={setBranch}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="Branch A">Branch A</SelectItem>
                <SelectItem value="Branch B">Branch B</SelectItem>
                <SelectItem value="Branch C">Branch C</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Category Filter</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Beverages">Beverages</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
                <SelectItem value="Office Supplies">Office Supplies</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-red-600 hover:bg-red-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Identify At-Risk Items
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">Items at Risk</p>
                <p className="text-2xl font-bold text-red-600">{results.length}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Potential Loss</p>
                <p className="text-2xl font-bold text-orange-600">
                  ${results.reduce((sum, r) => sum + r.potential_loss, 0).toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Recoverable Value</p>
                <p className="text-2xl font-bold text-green-600">
                  ${results.reduce((sum, r) => sum + r.estimated_savings, 0).toLocaleString()}
                </p>
              </div>
            </div>

            {/* Items List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">At-Risk Items</h3>
                <Badge variant="outline">
                  Sorted by urgency
                </Badge>
              </div>

              {results.length === 0 ? (
                <div className="text-center p-8 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-green-700 font-medium">No items expiring within {expiryWindow} days</p>
                  <p className="text-sm text-gray-600 mt-1">Your inventory is healthy!</p>
                </div>
              ) : (
                results.map((item, idx) => (
                  <div 
                    key={idx}
                    className={`border rounded-lg p-4 ${
                      item.urgency === "critical" ? "bg-red-50 border-red-300" :
                      item.urgency === "high" ? "bg-orange-50 border-orange-300" :
                      "bg-yellow-50 border-yellow-300"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{item.name}</p>
                          <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                          <Badge 
                            variant={item.urgency === "critical" ? "destructive" : "default"}
                            className={item.urgency === "high" ? "bg-orange-600" : ""}
                          >
                            {item.urgency}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">
                          {item.category} • {item.branch}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`text-2xl font-bold ${
                          item.urgency === "critical" ? "text-red-600" :
                          item.urgency === "high" ? "text-orange-600" :
                          "text-yellow-600"
                        }`}>
                          {item.days_to_expiry}
                        </p>
                        <p className="text-xs text-gray-600">days left</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div className="p-2 bg-white rounded">
                        <p className="text-xs text-gray-600">Current Stock</p>
                        <p className="text-sm font-bold">{item.current_stock} units</p>
                      </div>
                      <div className="p-2 bg-white rounded">
                        <p className="text-xs text-gray-600">Potential Loss</p>
                        <p className="text-sm font-bold text-red-600">
                          ${item.potential_loss.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div className="flex items-center gap-2">
                        {item.recommended_action.includes("Bundle") && <Tag className="w-4 h-4 text-blue-600" />}
                        {item.recommended_action.includes("transfer") && <ArrowRightLeft className="w-4 h-4 text-purple-600" />}
                        <div>
                          <p className="text-xs text-gray-600">Recommended Action</p>
                          <p className="text-sm font-medium">{item.recommended_action}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-600">Est. Savings</p>
                        <p className="text-sm font-bold text-green-600">
                          ${item.estimated_savings.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {results.length > 0 && (
              <div className="flex items-center gap-2 text-sm p-3 bg-red-50 rounded-lg">
                <Sparkles className="w-4 h-4 text-red-600" />
                <span className="text-gray-700">
                  AI Recommendation: Implementing suggested actions could recover ${
                    results.reduce((sum, r) => sum + r.estimated_savings, 0).toLocaleString()
                  } ({Math.round((results.reduce((sum, r) => sum + r.estimated_savings, 0) / results.reduce((sum, r) => sum + r.potential_loss, 0)) * 100)}% of potential loss).
                  Focus on {results.filter(r => r.urgency === "critical").length} critical items first.
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

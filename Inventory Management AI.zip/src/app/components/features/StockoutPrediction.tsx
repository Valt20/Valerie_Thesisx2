import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { AlertTriangle, Sparkles, Clock, Package } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const generateStockoutPredictions = (horizon: number, serviceLevel: number) => {
  const items = [
    { id: 8901, name: "USB Flash Drive 32GB", category: "Electronics" },
    { id: 8902, name: "HDMI Cable 2m", category: "Electronics" },
    { id: 8903, name: "Laptop Bag Professional", category: "Office Supplies" },
    { id: 8904, name: "Desk Pad XL", category: "Office Supplies" },
    { id: 8905, name: "Wireless Charger Qi", category: "Electronics" },
    { id: 8906, name: "Notebook A5 Premium", category: "Office Supplies" },
    { id: 8907, name: "Pen Set Executive", category: "Office Supplies" },
  ];

  const predictions = items.map(item => {
    const currentStock = Math.floor(Math.random() * 100) + 20;
    const dailyUsage = Math.random() * 10 + 2;
    const usageVariability = Math.random() * 0.3 + 0.1; // 10-40% variation
    
    // Simple stockout prediction
    const daysUntilStockout = Math.floor(currentStock / dailyUsage);
    
    // Find which week the stockout will occur
    let stockoutWeek = null;
    for (let week = 1; week <= horizon; week++) {
      if (daysUntilStockout <= (week * 7)) {
        stockoutWeek = week;
        break;
      }
    }
    
    // Calculate stockout probability based on variability and service level
    const baseProb = stockoutWeek ? (1 - (daysUntilStockout / (horizon * 7))) * 100 : 0;
    const variabilityFactor = usageVariability * 50;
    const serviceLevelAdjustment = (100 - serviceLevel) / 2;
    
    const stockoutProbability = Math.min(95, Math.max(5, 
      baseProb + variabilityFactor + serviceLevelAdjustment + (Math.random() * 20 - 10)
    ));
    
    const confidence = 100 - (usageVariability * 100);
    
    let recommendedAction = "";
    let urgency = "";
    
    if (daysUntilStockout < 7) {
      recommendedAction = "Expedite order + increase safety stock";
      urgency = "critical";
    } else if (daysUntilStockout < 14) {
      recommendedAction = "Place emergency order immediately";
      urgency = "high";
    } else if (daysUntilStockout < 21) {
      recommendedAction = "Schedule reorder this week";
      urgency = "medium";
    } else {
      recommendedAction = "Monitor and plan standard reorder";
      urgency = "low";
    }
    
    const reorderQty = Math.ceil(dailyUsage * 30); // 30 days supply
    const leadTime = Math.floor(Math.random() * 10) + 3; // 3-13 days
    
    return {
      item_id: item.id,
      product: item.name,
      category: item.category,
      current_stock: currentStock,
      daily_usage: Math.round(dailyUsage * 10) / 10,
      days_until_stockout: daysUntilStockout,
      stockout_week: stockoutWeek,
      stockout_probability: Math.round(stockoutProbability),
      confidence: Math.round(confidence),
      recommended_action: recommendedAction,
      urgency: urgency,
      recommended_reorder_qty: reorderQty,
      supplier_lead_time: leadTime,
      order_by_date: new Date(Date.now() + (daysUntilStockout - leadTime) * 24 * 60 * 60 * 1000).toLocaleDateString()
    };
  }).sort((a, b) => a.days_until_stockout - b.days_until_stockout);

  // Create heatmap data
  const heatmapData = [];
  for (let week = 1; week <= horizon; week++) {
    const weekData: any = { week: `W${week}` };
    items.forEach((item, idx) => {
      const prediction = predictions[idx];
      if (prediction.stockout_week === week) {
        weekData[item.name] = prediction.stockout_probability;
      }
    });
    heatmapData.push(weekData);
  }

  return { predictions, heatmapData };
};

export function StockoutPrediction() {
  const [horizon, setHorizon] = useState("4");
  const [serviceLevel, setServiceLevel] = useState("95");
  const [results, setResults] = useState<any | null>(null);

  const handleGenerate = () => {
    const data = generateStockoutPredictions(parseInt(horizon), parseInt(serviceLevel));
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          Stockout Prediction & Prevention
        </CardTitle>
        <CardDescription>
          AI-predicted stockouts with recommended preventive actions
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
          <div className="space-y-2">
            <Label>Prediction Horizon</Label>
            <Select value={horizon} onValueChange={setHorizon}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4">4 weeks</SelectItem>
                <SelectItem value="8">8 weeks</SelectItem>
                <SelectItem value="12">12 weeks</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Target Service Level</Label>
            <Select value={serviceLevel} onValueChange={setServiceLevel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90">90% - Standard</SelectItem>
                <SelectItem value="95">95% - High</SelectItem>
                <SelectItem value="99">99% - Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-orange-600 hover:bg-orange-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Predict Stockout Risk
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-4 gap-4">
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-sm text-gray-600">Critical Risk</p>
                <p className="text-2xl font-bold text-red-600">
                  {results.predictions.filter((r: any) => r.urgency === "critical").length}
                </p>
                <p className="text-xs text-gray-600 mt-1">Within 7 days</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">High Risk</p>
                <p className="text-2xl font-bold text-orange-600">
                  {results.predictions.filter((r: any) => r.urgency === "high").length}
                </p>
                <p className="text-xs text-gray-600 mt-1">Within 14 days</p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="text-sm text-gray-600">Medium Risk</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {results.predictions.filter((r: any) => r.urgency === "medium").length}
                </p>
                <p className="text-xs text-gray-600 mt-1">Within 21 days</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Avg Confidence</p>
                <p className="text-2xl font-bold text-blue-600">
                  {Math.round(results.predictions.reduce((sum: number, r: any) => sum + r.confidence, 0) / results.predictions.length)}%
                </p>
              </div>
            </div>

            {/* Risk Timeline Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Stockout Risk by Days Remaining</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={results.predictions}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="product" angle={-15} textAnchor="end" height={100} tick={{ fontSize: 10 }} />
                  <YAxis label={{ value: "Days Until Stockout", angle: -90, position: "insideLeft" }} />
                  <Tooltip />
                  <Bar dataKey="days_until_stockout" name="Days Left">
                    {results.predictions.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={
                        entry.urgency === "critical" ? "#ef4444" :
                        entry.urgency === "high" ? "#f97316" :
                        entry.urgency === "medium" ? "#f59e0b" :
                        "#10b981"
                      } />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Predictions List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Stockout Risk Analysis</h3>
                <Badge variant="outline">Sorted by urgency</Badge>
              </div>

              {results.predictions.map((item: any, idx: number) => (
                <div 
                  key={idx}
                  className={`border rounded-lg p-4 ${
                    item.urgency === "critical" ? "bg-red-50 border-red-300" :
                    item.urgency === "high" ? "bg-orange-50 border-orange-300" :
                    item.urgency === "medium" ? "bg-yellow-50 border-yellow-300" :
                    "bg-green-50 border-green-300"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.product}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        <Badge 
                          variant={item.urgency === "critical" || item.urgency === "high" ? "destructive" : "default"}
                          className={
                            item.urgency === "high" ? "bg-orange-600" :
                            item.urgency === "medium" ? "bg-yellow-600" :
                            item.urgency === "low" ? "bg-green-600" : ""
                          }
                        >
                          {item.urgency} urgency
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600">Confidence</p>
                      <p className="text-lg font-bold">{item.confidence}%</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3 mb-3">
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Current Stock</p>
                      <p className="text-lg font-bold">{item.current_stock}</p>
                      <p className="text-xs text-gray-600">units</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Daily Usage</p>
                      <p className="text-lg font-bold">{item.daily_usage}</p>
                      <p className="text-xs text-gray-600">units/day</p>
                    </div>
                    <div className={`p-2 rounded ${
                      item.days_until_stockout < 7 ? "bg-red-100" :
                      item.days_until_stockout < 14 ? "bg-orange-100" :
                      "bg-yellow-100"
                    }`}>
                      <p className="text-xs text-gray-600">Days Until Out</p>
                      <p className={`text-lg font-bold ${
                        item.days_until_stockout < 7 ? "text-red-600" :
                        item.days_until_stockout < 14 ? "text-orange-600" :
                        "text-yellow-600"
                      }`}>
                        {item.days_until_stockout}
                      </p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Stockout Risk</p>
                      <p className="text-lg font-bold text-red-600">{item.stockout_probability}%</p>
                      {item.stockout_week && (
                        <p className="text-xs text-gray-600">Week {item.stockout_week}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div className="p-3 bg-white rounded border">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-gray-600" />
                        <p className="text-xs text-gray-600">Lead Time</p>
                      </div>
                      <p className="text-sm font-bold">{item.supplier_lead_time} days</p>
                      <p className="text-xs text-gray-600 mt-1">Order by: {item.order_by_date}</p>
                    </div>
                    <div className="p-3 bg-white rounded border">
                      <div className="flex items-center gap-2 mb-1">
                        <Package className="w-4 h-4 text-gray-600" />
                        <p className="text-xs text-gray-600">Recommended Order</p>
                      </div>
                      <p className="text-sm font-bold">{item.recommended_reorder_qty} units</p>
                      <p className="text-xs text-gray-600 mt-1">~30 days supply</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                    <div className="flex-1">
                      <p className="text-xs text-gray-600">Recommended Action</p>
                      <p className="text-sm font-medium">{item.recommended_action}</p>
                    </div>
                    <Button 
                      size="sm" 
                      variant={item.urgency === "critical" ? "destructive" : "default"}
                      className={item.urgency === "high" ? "bg-orange-600 hover:bg-orange-700" : ""}
                    >
                      {item.urgency === "critical" || item.urgency === "high" ? "Order Now" : "Schedule Order"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-orange-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-orange-600" />
              <span className="text-gray-700">
                AI Alert: {results.predictions.filter((r: any) => r.urgency === "critical").length} critical items need 
                immediate reordering to prevent stockouts. 
                {results.predictions.filter((r: any) => r.urgency === "high").length > 0 &&
                  ` Additionally, ${results.predictions.filter((r: any) => r.urgency === "high").length} items require 
                  emergency orders within the next week.`
                }
                Maintaining {serviceLevel}% service level requires proactive action.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

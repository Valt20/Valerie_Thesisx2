import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Target, Sparkles, AlertTriangle, TrendingUp } from "lucide-react";
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const generateHighProfitData = (timeHorizon: number) => {
  const items = [
    { id: 4321, name: "Ergonomic Keyboard", category: "Electronics" },
    { id: 4322, name: "Noise-Cancelling Headphones", category: "Electronics" },
    { id: 4323, name: "Standing Desk Converter", category: "Furniture" },
    { id: 4324, name: "Executive Chair Premium", category: "Furniture" },
    { id: 4325, name: "Monitor 4K 27-inch", category: "Electronics" },
    { id: 4326, name: "Wireless Charging Pad", category: "Electronics" },
    { id: 4327, name: "Conference Room Camera", category: "Electronics" },
  ];

  return items.map(item => {
    const sellingPrice = Math.floor(Math.random() * 300) + 100;
    const costPrice = sellingPrice * (0.5 + Math.random() * 0.3); // 50-80% of selling price
    const profitPerUnit = sellingPrice - costPrice;
    const margin = ((profitPerUnit / sellingPrice) * 100);
    
    const avgWeeklySales = Math.floor(Math.random() * 50) + 10;
    const stockouts = Math.floor(Math.random() * 20) + 3;
    const avgStockoutDuration = Math.floor(Math.random() * 5) + 2; // days
    
    const lostSales = stockouts * (avgWeeklySales / 7) * avgStockoutDuration;
    const lostRevenue = lostSales * profitPerUnit;
    
    const forecastWeeklyProfit = (avgWeeklySales * profitPerUnit * (timeHorizon / 7));
    const potentialProfit = forecastWeeklyProfit + lostRevenue;
    
    const currentStock = Math.floor(Math.random() * 30) + 5;
    const recommendedSafetyStock = Math.ceil((avgWeeklySales / 7) * 14); // 2 weeks of demand
    
    return {
      item_id: item.id,
      product: item.name,
      category: item.category,
      profit_per_unit: Math.round(profitPerUnit),
      margin: Math.round(margin * 10) / 10,
      selling_price: Math.round(sellingPrice),
      forecast_weekly_profit: Math.round(forecastWeeklyProfit),
      stockouts_count: stockouts,
      lost_revenue: Math.round(lostRevenue),
      stockout_risk: currentStock < recommendedSafetyStock ? "high" : "medium",
      current_stock: currentStock,
      recommended_safety_stock: recommendedSafetyStock,
      recommended_action: currentStock < recommendedSafetyStock 
        ? "Increase safety stock immediately" 
        : "Maintain current levels with monitoring",
      priority_score: Math.round((profitPerUnit * stockouts) / 10),
      avg_weekly_sales: avgWeeklySales
    };
  }).sort((a, b) => b.priority_score - a.priority_score);
};

export function HighProfitItems() {
  const [timeHorizon, setTimeHorizon] = useState("4");
  const [results, setResults] = useState<any[] | null>(null);

  const handleGenerate = () => {
    const data = generateHighProfitData(parseInt(timeHorizon));
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5 text-green-600" />
          High-Profit Items with Stockout Risk
        </CardTitle>
        <CardDescription>
          Identify profit-driving products that frequently run out of stock - prioritize these for inventory investment
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 gap-4 p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="space-y-2">
            <Label>Analysis Time Horizon</Label>
            <Select value={timeHorizon} onValueChange={setTimeHorizon}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="4">4 weeks</SelectItem>
                <SelectItem value="8">8 weeks</SelectItem>
                <SelectItem value="12">12 weeks (quarter)</SelectItem>
                <SelectItem value="26">26 weeks (half year)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-green-600 hover:bg-green-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Analyze High-Profit Opportunities
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Lost Revenue</p>
                <p className="text-2xl font-bold text-red-600">
                  ${results.reduce((sum, r) => sum + r.lost_revenue, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">Due to stockouts</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Forecast Profit</p>
                <p className="text-2xl font-bold text-blue-600">
                  ${results.reduce((sum, r) => sum + r.forecast_weekly_profit, 0).toLocaleString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">Next {timeHorizon} weeks</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">High Risk Items</p>
                <p className="text-2xl font-bold text-orange-600">
                  {results.filter(r => r.stockout_risk === "high").length}
                </p>
                <p className="text-xs text-gray-600 mt-1">Need attention</p>
              </div>
            </div>

            {/* Profit vs Stockout Chart */}
            <div>
              <h3 className="text-sm font-semibold mb-3">Profit Margin vs Stockout Frequency</h3>
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    type="number" 
                    dataKey="margin" 
                    name="Margin" 
                    unit="%" 
                    label={{ value: "Profit Margin (%)", position: "bottom" }}
                  />
                  <YAxis 
                    type="number" 
                    dataKey="stockouts_count" 
                    name="Stockouts"
                    label={{ value: "Stockouts", angle: -90, position: "left" }}
                  />
                  <Tooltip 
                    cursor={{ strokeDasharray: '3 3' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white p-3 border rounded-lg shadow-lg">
                            <p className="font-medium">{data.product}</p>
                            <p className="text-sm">Margin: {data.margin}%</p>
                            <p className="text-sm">Stockouts: {data.stockouts_count}</p>
                            <p className="text-sm text-red-600">Lost: ${data.lost_revenue.toLocaleString()}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Scatter data={results} fill="#10b981">
                    {results.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.stockout_risk === "high" ? "#ef4444" : "#10b981"}
                      />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>

            {/* Priority Items List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Priority Items (Sorted by Impact)</h3>
                <Badge variant="outline">Top opportunities</Badge>
              </div>

              {results.map((item, idx) => (
                <div 
                  key={idx}
                  className={`border rounded-lg p-4 ${
                    item.stockout_risk === "high" ? "bg-red-50 border-red-300" : "bg-green-50 border-green-300"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{item.product}</p>
                        <Badge variant="outline" className="text-xs">ID: {item.item_id}</Badge>
                        <Badge variant="secondary" className="text-xs">{item.category}</Badge>
                        {idx < 3 && (
                          <Badge className="bg-yellow-500">
                            <TrendingUp className="w-3 h-3 mr-1" />
                            Top Priority
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Badge 
                      variant={item.stockout_risk === "high" ? "destructive" : "default"}
                      className={item.stockout_risk === "medium" ? "bg-orange-600" : ""}
                    >
                      {item.stockout_risk} risk
                    </Badge>
                  </div>

                  <div className="grid grid-cols-4 gap-3 mb-3">
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Profit/Unit</p>
                      <p className="text-lg font-bold text-green-600">${item.profit_per_unit}</p>
                      <p className="text-xs text-gray-600">{item.margin}% margin</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Weekly Profit</p>
                      <p className="text-lg font-bold text-blue-600">
                        ${(item.forecast_weekly_profit / parseInt(timeHorizon) * 7).toLocaleString()}
                      </p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Stockouts</p>
                      <p className="text-lg font-bold text-red-600">{item.stockouts_count}</p>
                      <p className="text-xs text-gray-600">in period</p>
                    </div>
                    <div className="p-2 bg-white rounded">
                      <p className="text-xs text-gray-600">Lost Revenue</p>
                      <p className="text-lg font-bold text-red-600">${item.lost_revenue.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white rounded-lg border mb-2">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="text-xs text-gray-600">Current Stock</p>
                        <p className="text-sm font-bold">{item.current_stock} units</p>
                      </div>
                      <AlertTriangle className="w-4 h-4 text-orange-600" />
                      <div>
                        <p className="text-xs text-gray-600">Recommended</p>
                        <p className="text-sm font-bold text-green-600">{item.recommended_safety_stock} units</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600">Increase by</p>
                      <p className="text-sm font-bold text-blue-600">
                        +{Math.max(0, item.recommended_safety_stock - item.current_stock)} units
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-700">
                      <span className="font-medium">Action:</span> {item.recommended_action}
                    </p>
                    <Button size="sm" variant={item.stockout_risk === "high" ? "destructive" : "default"}>
                      Adjust Stock Level
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-green-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-green-600" />
              <span className="text-gray-700">
                AI Insight: Optimizing stock levels for top 3 items could capture additional 
                ${results.slice(0, 3).reduce((sum, r) => sum + r.lost_revenue, 0).toLocaleString()} in revenue. 
                Total opportunity across all items: ${results.reduce((sum, r) => sum + r.lost_revenue, 0).toLocaleString()}.
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

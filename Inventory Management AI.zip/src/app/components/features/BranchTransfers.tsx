import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Building2, Sparkles, ArrowRight, TruckIcon } from "lucide-react";

const generateTransferData = (maxTransferValue: number) => {
  const branches = ["Branch A - Downtown", "Branch B - Uptown", "Branch C - Suburb"];
  const items = [
    { id: 7890, name: "Desk Organizer", unitCost: 15 },
    { id: 7891, name: "File Cabinet", unitCost: 200 },
    { id: 7892, name: "Conference Table", unitCost: 600 },
    { id: 7893, name: "Printer Paper Box", unitCost: 4 },
    { id: 7894, name: "Monitor Stand", unitCost: 45 },
  ];

  const transfers = [];
  let totalValue = 0;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const fromBranch = branches[Math.floor(Math.random() * branches.length)];
    let toBranch = branches[Math.floor(Math.random() * branches.length)];
    while (toBranch === fromBranch) {
      toBranch = branches[Math.floor(Math.random() * branches.length)];
    }

    const transferQty = Math.floor(Math.random() * 50) + 10;
    const transferValue = transferQty * item.unitCost;
    const transportCost = Math.floor(transferValue * 0.05) + 20;
    const purchaseCost = transferValue * 1.15; // 15% markup if buying new
    const savings = purchaseCost - (transferValue + transportCost);

    const reasons = [
      "Excess inventory at source",
      "Low demand at source branch",
      "High demand at destination",
      "Overstock reduction",
      "Seasonal demand shift"
    ];

    if (totalValue + transferValue <= maxTransferValue) {
      transfers.push({
        item_id: item.id,
        product: item.name,
        from_branch: fromBranch,
        to_branch: toBranch,
        transfer_qty: transferQty,
        transfer_value: Math.round(transferValue),
        transport_cost: transportCost,
        savings: Math.round(savings),
        reason: reasons[Math.floor(Math.random() * reasons.length)],
        lead_time_days: Math.floor(Math.random() * 3) + 1
      });
      totalValue += transferValue;
    }
  }

  return {
    transfers,
    totalSavings: transfers.reduce((sum, t) => sum + t.savings, 0),
    totalTransportCost: transfers.reduce((sum, t) => sum + t.transport_cost, 0),
    totalValue: transfers.reduce((sum, t) => sum + t.transfer_value, 0)
  };
};

export function BranchTransfers() {
  const [maxTransferValue, setMaxTransferValue] = useState("50000");
  const [timeWindow, setTimeWindow] = useState("7");
  const [results, setResults] = useState<any | null>(null);

  const handleGenerate = () => {
    const data = generateTransferData(parseInt(maxTransferValue));
    setResults(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5" />
          Inventory Transfer Recommendations
        </CardTitle>
        <CardDescription>
          Optimize inventory distribution across branches to avoid unnecessary purchases
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
          <div className="space-y-2">
            <Label>Max Transfer Value ($)</Label>
            <Input
              type="number"
              value={maxTransferValue}
              onChange={(e) => setMaxTransferValue(e.target.value)}
              placeholder="50000"
            />
            <p className="text-xs text-gray-600">Total value limit for transfers</p>
          </div>

          <div className="space-y-2">
            <Label>Time Window</Label>
            <Select value={timeWindow} onValueChange={setTimeWindow}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3">3 days</SelectItem>
                <SelectItem value="7">7 days</SelectItem>
                <SelectItem value="14">14 days</SelectItem>
                <SelectItem value="30">30 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleGenerate} className="w-full bg-purple-600 hover:bg-purple-700">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate Transfer Plan
        </Button>

        {/* Outputs */}
        {results && (
          <div className="space-y-6">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-sm text-gray-600">Total Savings</p>
                <p className="text-2xl font-bold text-green-600">
                  ${results.totalSavings.toLocaleString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">vs. buying new</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-sm text-gray-600">Transport Cost</p>
                <p className="text-2xl font-bold text-orange-600">
                  ${results.totalTransportCost.toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Transfers Suggested</p>
                <p className="text-2xl font-bold text-blue-600">{results.transfers.length}</p>
              </div>
            </div>

            {/* Transfer suggestions */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Recommended Transfers</h3>
                <Badge variant="outline">Within {timeWindow} days</Badge>
              </div>

              {results.transfers.length === 0 ? (
                <div className="text-center p-8 bg-gray-50 rounded-lg border">
                  <p className="text-gray-700 font-medium">No transfers recommended at this time</p>
                  <p className="text-sm text-gray-600 mt-1">All branches have balanced inventory levels</p>
                </div>
              ) : (
                results.transfers.map((transfer: any, idx: number) => (
                  <div key={idx} className="border rounded-lg p-4 bg-white">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{transfer.product}</p>
                          <Badge variant="outline" className="text-xs">ID: {transfer.item_id}</Badge>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">{transfer.reason}</p>
                      </div>
                      <Badge className="bg-purple-600">{transfer.transfer_qty} units</Badge>
                    </div>

                    <div className="flex items-center gap-3 mb-4 p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-gray-600" />
                        <div>
                          <p className="text-xs text-gray-600">From</p>
                          <p className="text-sm font-medium">{transfer.from_branch}</p>
                        </div>
                      </div>
                      
                      <ArrowRight className="w-5 h-5 text-purple-600" />
                      
                      <div className="flex-1 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-gray-600" />
                        <div>
                          <p className="text-xs text-gray-600">To</p>
                          <p className="text-sm font-medium">{transfer.to_branch}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-3">
                      <div className="p-2 bg-gray-50 rounded">
                        <p className="text-xs text-gray-600">Transfer Value</p>
                        <p className="text-sm font-bold">${transfer.transfer_value.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-orange-50 rounded">
                        <p className="text-xs text-gray-600">Transport Cost</p>
                        <p className="text-sm font-bold text-orange-600">${transfer.transport_cost}</p>
                      </div>
                      <div className="p-2 bg-green-50 rounded">
                        <p className="text-xs text-gray-600">Savings</p>
                        <p className="text-sm font-bold text-green-600">${transfer.savings.toLocaleString()}</p>
                      </div>
                      <div className="p-2 bg-blue-50 rounded">
                        <p className="text-xs text-gray-600">ETA</p>
                        <p className="text-sm font-bold text-blue-600">{transfer.lead_time_days} days</p>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-gray-600">
                        <TruckIcon className="w-4 h-4" />
                        <span>ROI: {Math.round((transfer.savings / transfer.transport_cost) * 100)}%</span>
                      </div>
                      <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                        Approve Transfer
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex items-center gap-2 text-sm p-3 bg-purple-50 rounded-lg">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-gray-700">
                AI Analysis: Implementing these {results.transfers.length} transfers will save ${results.totalSavings.toLocaleString()} 
                vs. purchasing new inventory. Net savings after transport: ${(results.totalSavings - results.totalTransportCost).toLocaleString()} 
                ({Math.round(((results.totalSavings - results.totalTransportCost) / results.totalSavings) * 100)}% efficiency).
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
